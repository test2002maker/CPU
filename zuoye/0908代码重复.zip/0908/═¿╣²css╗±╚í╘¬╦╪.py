#!/usr/bin/env python
# -*- coding:utf-8 -*-  
#====#====#====#====   
#Author:
#CreatDate:
#Version: 
#====#====#====#====
#案例:自己写个有超链接的标签,通过class样式,找到该标签的href属性值
from selenium import webdriver
# import os
# dr=webdriver.Firefox()
# dr.get('file:///'+os.path.abspath('html2/h02.html'))
# e=dr.find_element_by_css_selector('a.zz')
# print(e.get_attribute('href'))
# dr.quit()
dr=webdriver.Firefox()
dr.get('https://www.baidu.com')
e=dr.find_element_by_css_selector('a.hot-title')
print(e.get_attribute('href'))
dr.quit()