#!/usr/bin/env python
# -*- coding:utf-8 -*-  
#====#====#====#====   
#Author:
#CreatDate:
#Version: 
#====#====#====#====
#自己写一个html文件,定义两个id属性值相同的标签,通过id获取多个元素,
# 然后打印出各自其他的属性
from selenium import webdriver
import os
dr=webdriver.Firefox()
dr.get('file:///'+os.path.abspath('html2/h03.html'))
e=dr.find_elements_by_id('zz')
for i in range(len(e)):
    print(e[i].get_attribute('class'))
dr.quit()