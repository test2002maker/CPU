#!/usr/bin/env python
# -*- coding:utf-8 -*-  
#====#====#====#====   
#Author:
#CreatDate:
#Version: 
#====#====#====#====
from selenium import webdriver
import os
dr=webdriver.Firefox()
dr.get('file:///'+os.path.abspath('html2/h06.html'))
e=dr.find_elements_by_css_selector('p.z')
for i in e:
    print(i.get_attribute('id'))
dr.quit()

