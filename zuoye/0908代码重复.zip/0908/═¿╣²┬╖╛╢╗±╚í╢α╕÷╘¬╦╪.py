#!/usr/bin/env python
# -*- coding:utf-8 -*-  
#====#====#====#====   
#Author:
#CreatDate:
#Version: 
#====#====#====#====
# from selenium import webdriver
# import os
# dr=webdriver.Firefox()
# dr.get('file:///'+os.path.abspath('HTML02/09HTML.html'))
# # e=dr.find_elements_by_xpath("//input[@name='cin']")
# # e=dr.find_elements_by_xpath("//form[@id='loginForm']/input")
# e=dr.find_elements_by_xpath("//*[@name='cin']")
# print(len(e))
# print(e[0].get_attribute('type'))
# print(e[1].get_attribute('type'))
# dr.quit()
from selenium import webdriver
import os
# 1./html/body/form[1] --该路径下第一个form
# dr=webdriver.Firefox()
# dr.get('file:///'+os.path.abspath('html2/h07.html'))
# e=dr.find_elements_by_xpath('/html/body/form')
# print(len(e))
# print(e[0].get_attribute('method'))
# print(e[1].get_attribute('method'))
# dr.quit()

# 2.//form[1] --html下第一个form
# dr=webdriver.Firefox()
# dr.get('file:///'+os.path.abspath('html2/h07.html'))
# e=dr.find_elements_by_xpath('//form')
# print(len(e))
# print(e[0].get_attribute('method'))
# print(e[1].get_attribute('action'))
# dr.quit()

# 4.//form[input/@name='username'] --form里有input,i
# nput里的属性name是叫username的,第一个form,找的是form
# dr=webdriver.Firefox()
# dr.get('file:///'+os.path.abspath('html2/h07.html'))
# e=dr.find_elements_by_xpath('//form[input/@name="xx"]')
# print(len(e))
# print(e[0].get_attribute('method'))
# dr.quit()

# 7.//input[@name='continue'][@type='submit'] --
# type属性为'submit',name属性为'continue'的第一个input元素
dr=webdriver.Firefox()
dr.get('file:///'+os.path.abspath('html2/h07.html'))
e=dr.find_elements_by_xpath('//input[@name="zz"][@type="text"]')
print(len(e))
print(e[0].get_attribute('id'))
dr.quit()